<link rel="stylesheet" href="css/index.css">
<div class="hangp">
	<div class="container">
			<div class="spdb">
				<p>CHUYÊN MỤC ĐIỆN THOẠI</p>
			</div>
		</div>
		<div class="hang">
		<div class="container">
				<div class="row hangdt">
					<div class="col-xs-4 col-md-2 dt-img">
						<a href="index.php?page=apple" class='thumbnail'><img src="img/apple.png" alt=""></a>
					</div>
					<div class="col-xs-4 col-md-2 dt-img">
						<a href="index.php?page=samsung" class='thumbnail'><img src="img/ss.jpg" alt=""></a>
					</div>
					<div class="col-xs-4 col-md-2 dt-img">
						<a href="index.php?page=sony" class='thumbnail'><img src="img/sony.png" alt=""></a>
					</div>
					<div class="col-xs-4 col-md-2 dt-img">
						<a href="index.php?page=oppo" class='thumbnail'><img src="img/oppo.png" alt=""></a>
					</div>
					<div class="col-xs-4 col-md-2 dt-img">
						<a href="index.php?page=microsolf" class='thumbnail'><img src="img/microsolf.png" alt=""></a>
					</div>
					<div class="col-xs-4 col-md-2 dt-img">
						<a href="index.php?page=lg" class='thumbnail'><img src="img/lg.png" alt=""></a>
					</div>
				</div>
				</div>
				</div>
</div>