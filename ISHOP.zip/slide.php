<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/reponsive-menu.css">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	<div class="slidep">
		<div class="container-fluid">
			<div id="carousel-id" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="#carousel-id" data-slide-to="0" class=""></li>
					<li data-target="#carousel-id" data-slide-to="1" class=""></li>
					<li data-target="#carousel-id" data-slide-to="3" class=""></li>
					<li data-target="#carousel-id" data-slide-to="4" class=""></li>
					<li data-target="#carousel-id" data-slide-to="5" class=""></li>
					<li data-target="#carousel-id" data-slide-to="6" class="active"></li>
				</ol>
				<div class="carousel-inner">
				<div class="item">
						<img class='slider-hinh' alt="First slide" src="img/side1.jpg" width='100%'>
					</div>
					<div class="item">
						<img class='slider-hinh' alt="First slide" src="img/side1.jpg" width='100%'>
					</div>
					<div class="item">
						<img class='slider-hinh'  alt="Second slide" src="img/side2.jpg" width='100%'>
					</div>
					<div class="item">
						<img  class='slider-hinh' alt="Second slide" src="img/side3.jpg" width='100%'>
					</div>
					<div class="item">
						<img class='slider-hinh'  alt="Second slide" src="img/side4.jpg" width='100%'>
					</div>
					<div class="item">
						<img class='slider-hinh'  alt="Second slide" src="img/side5.jpg" width='100%'>
					</div>
					<div class="item active">
						<img class='slider-hinh' alt="Third slide" src="img/side6.jpg" width='100%'>
					</div>
				</div>
				<a class="left carousel-control" href="#carousel-id" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
				<a class="right carousel-control" href="#carousel-id" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
			</div>
		</div>
	</div>